from .instruct import Instruct as Instructor
from .claude import AnthropicInstructor as Anthropic