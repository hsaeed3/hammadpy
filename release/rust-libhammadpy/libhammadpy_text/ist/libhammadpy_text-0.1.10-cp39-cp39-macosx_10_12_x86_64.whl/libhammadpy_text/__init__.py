from .libhammadpy_text import *

__doc__ = libhammadpy_text.__doc__
if hasattr(libhammadpy_text, "__all__"):
    __all__ = libhammadpy_text.__all__